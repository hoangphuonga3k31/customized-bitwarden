export default class ChangePasswordRuntimeMessage {
  currentPassword: string;
  newPassword: string;
  url: string;
}
