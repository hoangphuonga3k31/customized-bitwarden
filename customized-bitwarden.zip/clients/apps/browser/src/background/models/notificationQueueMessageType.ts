export enum NotificationQueueMessageType {
  AddLogin = 0,
  ChangePassword = 1,
}
