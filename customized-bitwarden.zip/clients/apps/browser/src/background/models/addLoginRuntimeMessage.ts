export default class AddLoginRuntimeMessage {
  username: string;
  password: string;
  url: string;
}
