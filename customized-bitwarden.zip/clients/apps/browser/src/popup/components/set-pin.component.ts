import { Component } from "@angular/core";

import { SetPinComponent as BaseSetPinComponent } from "@bitwarden/angular/components/set-pin.component";

@Component({
  templateUrl: "set-pin.component.html",
})
export class SetPinComponent extends BaseSetPinComponent {}
