export default interface IconDetails {
  path: {
    19: string;
    38: string;
  };
  // Chrome does not support windowId, only Firefox
  windowId?: number;
}
