/**
 * Represents an HTML form whose elements can be autofilled
 */
export default class AutofillForm {
  /**
   * The unique identifier assigned to this field during collection of the page details
   */
  opid: string;
  /**
   * The HTML `name` attribute of the form field
   */
  htmlName: string;
  /**
   * The HTML `id` attribute of the form field
   */
  htmlID: string;
  /**
   * The HTML `action` attribute of the form field
   */
  htmlAction: string;
  /**
   * The HTML `method` attribute of the form field
   */
  htmlMethod: string;
}
