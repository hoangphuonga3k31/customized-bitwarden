export interface BaseResponse {
  object: string;
}
